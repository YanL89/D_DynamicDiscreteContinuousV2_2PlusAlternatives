BIC = function(f,listVar,D, specs){
  keep = c()
  bestBIC = 10e10
  keepGoing = TRUE
  while(keepGoing){
    keepGoing = FALSE
    candBIC = 10e10
    candVar = ""
    for(v in listVar){
      thisList = c(keep,v)
      bic = f(thisList,D, specs)
      if(bic < candBIC){
        candBIC = bic
        candVar = v
      }
    }
    if(candBIC < bestBIC){
      keep = c(keep, candVar)
      bestBIC = candBIC
      listVar = listVar[! listVar %in% candVar]
      cat("added ",candVar, "BIC = ", bestBIC, "\n")
      keepGoing = TRUE
    }
  }
  keep
}
