#' shuffles all data sets in a folder with the same order
#' requires all data set so have the same length
#' 
#' @param sourceFolder folder to read data from
#' @param destFolder folder te write shuffled data to
#' @export
shuffleDataSet = function(sourceFolder, destFolder){
  allFiles = list.files(sourceFolder)
  oneF = paste(sourceFolder, allFiles[1],sep="/")
  oneD = read.table(oneF, header = T)
  n = nrow(oneD)
  newO = sample(n, n)
  for(file in allFiles ){
    f = paste(sourceFolder,file,sep="/")
    outF = paste(destFolder,file,sep="/")
    D = read.table(f,header = T)
    D = D[newO,]
    write.table(D, outF, quote = F, row.names = F, col.names=TRUE)
  }
}

#' splits files in folder in 2 folder. 1st contains fracf1% of observations
#' 
#' @param sourceFolder folder of original files
#' @param f1 folder of first split
#' @param f2 folder of second split
#' @param fracf1 fraction of data to put in data set 1
#' @return nothing
#' @export
# splitDataSet = function(sourceFolder, f1, f2, fracf1){
#   allFiles = list.files(sourceFolder)
#   oneF = paste(sourceFolder, allFiles[1],sep="/")
#   oneD = read.table(oneF, header = T)
#   n = nrow(oneD)
#   end1 = round(fracf1*n)
#   start2 = end1 + 1
#   for(file in allFiles ){
#     f = paste(sourceFolder,file,sep="/")
#     outF1 = paste(f1,file,sep="/")
#     outF2 = paste(f2,file,sep="/")
#     D = read.table(f,header = T)
#     write.table(D[1:end1,], outF1, quote = F, row.names = F, col.names=TRUE)
#     write.table(D[start2:n,], outF2, quote = F, row.names = F, col.names=TRUE)
#   } 
# }