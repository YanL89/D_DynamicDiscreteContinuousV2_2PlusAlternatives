#' nested logit model functions
nlogit = list(
  LLVec = function(b, args){
   lambda = b[args$parIndex$lambda]
   
   Yut = list()
   I = list()
   
   W = matrix(0, args$n, args$nNest)
   if( ! is.null(args$XSplit))
    W = getUtilities(args$XSplit, b[args$parIndex$split], args$n)
   PInNest = list()
   for(k in 1:args$nNest){
     Yut[[k]] = getUtilities(args$XInNests[[k]] , b[args$parIndex$nests[[k]] ]
                             , args$n) / lambda[k] # 4.5
     I[[k]] = log(rowSums(exp(Yut[[k]]))) # "4.6"
     W[,k] = W[,k] + lambda[k] * I[[k]] # 4.4
     PInNest[[k]] = getPAlts(Yut[[k]])
   }
   
   PNest = getPAlts(W)
   
   p = rep(1, args$n)
   for(k in 1:args$nNest){
     p[args$YSplit == k] = p[args$YSplit == k] * PNest[args$YSplit == k, k]
      for(j in 1:ncol(PInNest[[k]]))
        p[args$YSplit == k & args$YInNests == j] = 
            p[args$YSplit == k & args$YInNests == j] * 
            PInNest[[k]][args$YSplit == k & args$YInNests == j, j]
   }
   p
  },
  
  computeArgs = function(spec, D){
    nNest = length(spec$split$specific)
    
    YInNests =  D[,spec$Y]
    YSplit = D[,spec$YSplit]
    YSplit = YSplit - min(YSplit) + 1
    
    if(nNest != length(unique(YSplit))){
      stop("incorrect number of nests")
    }
    
    #YInNestsList = list()
    for(i in 1:nNest){
      nalt = length(spec$nests[[i]]$specific)
      YInNests[YSplit == i] = YInNests[YSplit == i] - min(YInNests[YSplit == i]) + 1
      
      if(nalt != length(unique(YInNests[YSplit == i]))){
        errMsg = paste("incorrect number of alt in nest",i)
        stop(errMsg)
      }       
    }
    
    XSplit = NULL
    if(length(spec$split$common) != 0 | length(unlist(spec$split$specific)) != 0)
      XSplit = create_X(spec$split$common, spec$split$specific, D)
    XInNests = list()
    #nInNests = c()
    for(i in 1:nNest)
      XInNests[[i]] = create_X(spec$nests[[i]]$common, spec$nests[[i]]$specific, D)
    
    indexSplit = NULL
    index = 1
    if( ! is.null(XSplit)){
      indexSplit = 1:ncol(XSplit)
      index = ncol(XSplit) + 1
    }
    parIndex = list(split = indexSplit, nests = list(), lambda = NULL)
    for(i in 1:nNest){
      parIndex$nests[[i]] = index:(index + ncol(XInNests[[i]]) - 1)
      index = index + ncol(XInNests[[i]])
    }
    parIndex$lambda = index:(index + nNest -1)
    
    list(YSplit = YSplit, YInNests = YInNests, XSplit = XSplit
          , XInNests = XInNests, parIndex = parIndex, n = nrow(D), nNest = nNest
    #      , nInNests = nInNests)
          )
  },
  
  computeStart = function(spec, D){
   nPar = 0
   nPar = nPar + length(spec$split$common)
   for(s in spec$split$specific)
     nPar = nPar + length(s)
   
   for(n in spec$nests){
     nPar = nPar + length(n$common)
     for(s in n$specific)
       nPar = nPar + length(s)
   }
   nNest = length(spec$nests)
   c(rep(0,nPar), rep(0.5, nNest))
  },
  
  computeOther = function(spec, D){
    n = c()
    
    # split
    for(i in spec$split$common)
      n = c(n,paste(i, collapse="_"))
    for(i in spec$split$spec)
      n = c(n,i)
    
    for(nest in spec$nests){
      for(i in nest$common)
        n = c(n,paste(i, collapse="_"))
      for(i in nest$spec)
        n = c(n,i)      
    }
    nNest = length(spec$split$spec)
    l = paste("lambda",1:nNest,sep="_")
    n = c(n,l)
   list(names = n)
  }
) # nested logit function list
