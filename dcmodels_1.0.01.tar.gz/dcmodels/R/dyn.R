#' dyn model functions
dyn = list(
  LLVec = function(b, args){
    nparH = ncol(args$M[[1]][[1]])
    
    alpha = b[1:nparH]
    beta = b[(nparH+1):length(b)]
    
    LL = 0
    
    H = list()
    U = list()
    V = list()
    PAllObs = rep(1,args$spec$nObs)
    #Pall = matrix(0,16, 3)
    for(t in 1:args$spec$nTime){
      for(l in 1:(args$spec$nLook+1)){
        H[[l]] = as.matrix(args$M[[t]][[l]]) %*% alpha
        if(0 == ncol(H[[l]]))
        	H[[l]] = rep(0, args$spec$nObs)
        U[[l]] = matrix(args$X[[t]][[l]] %*% beta, args$spec$nObs, args$spec$nAlt, byrow = T)
        V[[l]] = UtoV(U[[l]])
      }
      W = getW(H,V)
      R = getR(U[[1]])
      P = getDynProbas(W,R,U[[1]],args$C[,t])
      P = maxVec(P,args$stop[,t])
      #Pall[[t]] = P
      #Pall[t,1] = sum(getDynProbas(W,R,U[[1]],rep(0,696)))
      #for(ch in 1:15)
      #	Pall[t,2] = Pall[t,2] +sum(getDynProbas(W,R,U[[1]],rep(ch,696)))
      #Pall[t,3] = sum(getDynProbas(W,R,U[[1]],rep(16,696)))
      #LL = LL + sum(log(P))
      PAllObs = PAllObs * P
    }
    #LL
    PAllObs
  },
  
  computeArgs = function(spec, D){
    Z = spec$First
    M = list()
    X = list()
    
    for(t in 1:spec$nTime){
      M[[t]] = list()
      X[[t]] = list()
      for(l in 1:(spec$nLook+1)){
        M[[t]][[l]] = getM(Z, t+l-1, spec)
        Dt = spec$modifyD(spec$D, spec$Time, spec$Global, Z, t+l-1)
        X[[t]][[l]] = create_X(spec$generic, spec$specific, Dt)
      }
      Z = updateZ(Z,spec$D[[t]],spec$C[,t],spec$varNames)
    }
    
    # check if we reached stop point already
    stopMat = matrix(0, spec$nObs, spec$nTime)
    for(t in 2:spec$nTime)
    	stopMat[,t] = (spec$C[,t-1] %in% spec$stopAlt)  | (stopMat[,t-1] == 1)

    list(spec = spec, M = M, X = X, C = spec$C, stop = stopMat)
    #c(spec, M = M, X = X, stop = stopMat)
  },
  
  computeStart = function(spec, D){
    npar = length(spec$payoff_alt) + length(spec$payoff_time) + length(spec$payoff_global)
    npar = npar + length(spec$generic)
    for(s in spec$specific)
      npar = npar + length(s)
    rep(0, npar)
  },
  
  computeMisc = function(spec, D){
    n = c(spec$payoff_alt, spec$payoff_time, spec$payoff_global)
    comIndex = 1
    for(com in spec$generic){
      n = c(n,paste("common",comIndex,sep="_"))
      comIndex = comIndex + 1
    }
    for(s in spec$specific)
      n = c(n,s)
    list(names = n)
  }
) # dyn function list

dynApply = function(M,spec){
	print("YO NAYEL DO YOU SEE THAT")
  args = dyn$computeArgs(spec,NULL)
  b = M$results$beta_hat
  predCount = matrix(0, spec$nTime, spec$nAlt+1)
  
  # DIRTY copy from LL function :(
  nparH = ncol(args$M[[1]][[1]])
  alpha = b[1:nparH]
  beta = b[(nparH+1):length(b)]
  
  H = list()
  U = list()
  V = list()
  for(t in 1:args$spec$nTime){
    for(l in 1:(args$spec$nLook+1)){
      H[[l]] = as.matrix(args$M[[t]][[l]]) %*% alpha
      if(0 == ncol(H[[l]]))
      	H[[l]] = rep(0, args$spec$nObs)
      U[[l]] = matrix(args$X[[t]][[l]] %*% beta, args$spec$nObs, args$spec$nAlt, byrow = T)
      V[[l]] = UtoV(U[[l]])
    }
    W = getW(H,V)
    R = getR(U[[1]])
    #P = getDynProbas(W,R,U[[1]],args$C[,t])
    for(choice in 0:spec$nAlt){
    	P = getDynProbas(W,R,U[[1]],rep(choice,spec$nObs))
    	P = minVec(P,1 - args$stop[,t])
      predCount[t,choice+1] = sum(P)    
    	}

  }
  predCount
}

dynCount = function(spec){
  count = matrix(0, spec$nTime, spec$nAlt + 1)
  for(t in 1:spec$nTime)
    for(a in 0:spec$nAlt)
      count[t,a+1] = sum(spec$C[,t] == a)
  count
}
