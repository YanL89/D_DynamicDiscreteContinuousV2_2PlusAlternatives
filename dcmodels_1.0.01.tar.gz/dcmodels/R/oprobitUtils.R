#' generates ordered probit choices
#' 
#' @param opVars predictors of OP
#' @param opBeta beta parameter
#' @param opAlphas alpha parameter
#' @param D the data set
#' @return OP choices
#' @export
genOprobit = function(oprobitVars, oprobitBeta, oprobitAlphas, D){
  X = as.matrix(D[,oprobitVars])
  nObs = nrow(X)
  nAlt = length(oprobitAlphas) + 2
  
  Z = X %*% oprobitBeta + rnorm(nObs)
  gamma = c(-100,0)
  for(i in oprobitAlphas)
    gamma = c(gamma, gamma[length(gamma)] + i)
  gamma = c(gamma, 1000)
  
  p = rep(0, nObs)
  for(i in 0:(nAlt-1))
    p[Z > gamma[i+1] & Z < gamma[i+2]] = i
  
  p
}