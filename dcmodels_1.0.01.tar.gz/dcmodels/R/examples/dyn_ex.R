library(dcmodels)
setwd("~/Documents")

spec = list(
	# data sets
	
	# this is the path to the data sets. here I specify a directory (vars) that contains 
	# data files suffixed by "alternatives". The names of the data sets (in vars folder) need to be :
	# alternatives1.txt
	# alternatives2.txt
	# ...
	# alternatives18.txt
	# variables need to be listed for all alternatives. in this example there is only one variable
	# (cost) and 16 aternatives so the variables in each data file need to be
	# cost.1, cost.2, cost.3, ..., cost.16
	D = "vars/alternatives",
	
	# this is the data file with time dependant attributes shared by all alternatives. In this example
	# there are 18 time periods (with 16 + 2 look ahead) and 3 variables (t1, t215 and t16) so the
	# variables in there need to be
	# t1.1, t1.2, ..., t1.18, t215.1, t215.2, ..., t215.18, t16.1, t16.2, ..., t16.18
	Time = "vars/time.txt",
	
	# this is the global attributes. it looks like a normal data set
	Global = "vars/global.txt",
	
	# this is the attributes of the alternative held at the beginning of the process. you need one value
	# for each variable is D and Time, but you don't need time replications
	# in our example the variables need to be:
	# cost, t1, t215, t16
	First = "vars/first.txt",
	
	# this is the choice file
	choices = "vars/choices.txt",
	
	# speficy one period payoffs
	# there are 3 parts here that correspond to what part of the data the variable is from
	# these are variables from the alternative data
	payoff_alt = c(),
	# these are variables that are time dependant
	payoff_time = c("t16"),
	# these are variables from the global data set
	payoff_global = c(),
	
	# specify utilities. variables here must be created
	# in the modifyD function. I explain this later
	generic = list(
		c("diff1","diff2","diff3","diff4","diff5","diff6","diff7","diff8"
			,"diff9","diff10","diff11","diff12","diff13","diff14"
			,"diff15","zero")),
	specific = list(
		c(), # 1
		c(), # 2
		c(), # 3
		c(), # 4
		c(), # 5
		c(), # 6
		c(), # 7
		c(), # 8
		c(), # 9
		c(), # 10
		c(), # 11
		c(), # 12
		c(), # 13
		c(), # 14
		c(), # 15
		c("t1","t16","evening","friday","philly","farepaid")), # 16

	# function to create data set at time t
	# if you use fancy stuff (like we do in our example)
	# if you just use data from D, Time, Global and Z you should cbind them together:
	# return(cbind(D[[t]], Time, Global, Z)
	#
	# if you need to compute fancy variables that depend on stuff in these various data sets
	# this is where you do it
	#
	# at the end the data frame returned by this needs to contain all variables used in your payoff
	# and all variables included in your utilities
	modifyD = function(D,Time,Global,Z,t){
		Dpratt = D[[t]]
		for(i in 1:15){
			Dpratt[,paste("diff",i,sep="")] = Dpratt[,paste("cost",i,sep=".")] - Z$cost
		}

		Timet = Time_select_vars(Time,"t1",t)

		Dpratt$t1 = 1*(t==1)
		Dpratt$t16 = 1*(t==16)
		Dpratt$t215 = 1*(t > 1 && t < 16)
		Dpratt$t216 = 1*(t > 1 && t <= 16)
		Dpratt = cbind(Dpratt, Global)
	
		Dpratt$farepaid = Z$cost
		Dpratt
	},

	# specify your coefficients for dynamic
	b = c(c(2), c(-0.02, -6, -5, -4, 1, 1, 0.02)),
	# for logit :
	logitB = c(c(2), c(-0.02, -6, -5, -4, 1, 1, 0.02)),
	nTime = 16,
	nLook = 2,
	ASC = FALSE,
	stopAlt = c(16,7),
	SD = "none"
)

# DO NOT RUN THIS
#spec = checkFillDynSpec(spec)

# only thing to specify here is the number of simulations
simSpec=list(B=2)

L = dynCheckAsympProperties(spec, simSpec)

# do whatever you want with these matrices
Matrices = compileDyn(L)
