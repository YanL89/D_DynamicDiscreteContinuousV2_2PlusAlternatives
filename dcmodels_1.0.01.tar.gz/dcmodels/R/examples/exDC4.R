library(dcmodels)

# generate a data set
nObs = 500
nVars = 10
type = "norm"
seed = 1234
D = genData(nObs, nVars, type, seed)

# model spec
generic = list(c("X1","X2","X3"))
specific = list(c("X4"), c("X5"), c("X6"))
ASC = FALSE # to keep it fast

# utility coefficients. typically you don't know that 
# but we're generating choices here
b = c(-1,1,1,1)
# covariance of differences, typically you don't know that either
SDiff = matrix(c(1, 0.5, 0.5, 1),2,2)
D$Ypr = genChoiceProbit(generic, specific, b, D, NULL, SDiff, ASC)

# generate a regression. this is not correlated with the OP so me expect a correlation of 0
bReg = c(1,1,2,-2)
sReg = 5
reg = c("X7","X8","X9","X10")
D$Yreg = as.matrix(D[,reg]) %*% bReg + rnorm(nObs,0,sReg)

#' DC4 specs
specDC4 = list(
  reg = reg,
  generic = generic,
  specific = specific,
  ASC = TRUE,
  Yreg = "Yreg",
  Ypr = "Ypr",
  SD = "none"
)

dc4Model = model(dc4, specDC4, D)
