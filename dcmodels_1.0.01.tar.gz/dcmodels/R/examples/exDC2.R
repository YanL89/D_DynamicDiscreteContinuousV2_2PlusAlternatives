library(dcmodels)

# generate a data set
nObs = 100
nVars = 10
type = "norm"
seed = 1234
D = genData(nObs, nVars, type, seed)

# generate an OP
Z = c("X1","X2","X3","X4","X5")
a = c(1,1)
bOp = c(1, -1, 0.5, 0.5, 2)
D$Yop = genOprobit(Z, bOp, a, D)

# generate a regression. this is not correlated with the OP so me expect a correlation of 0
bReg = c(1,1,1,2,-2)
sReg = 5
reg = c("X6","X7","X8","X9","X10")
D$Yreg = as.matrix(D[,reg]) %*% bReg + rnorm(nObs,0,sReg)

#' DC2 specs
specDC2 = list(
  op = Z,
  reg = reg,
  Yop = "Yop",
  Yreg = "Yreg"
  #Y = "Yop",  
  #Z = c("X1","X2","X3","X4","X5")
)


spec = specDC2
modelFns = dc2

dc2Model = model(dc2, specDC2, D)

write.table(D[,c("X1","X2","X3","X4","X5")],"~/xdisc.txt",row.names=F,col.names=F)
write.table(D[,c("X6","X7","X8","X9","X10")],"~/xcont.txt",row.names=F,col.names=F)
write.table(D$Yop,"~/ydisc.txt",row.names=F,col.names=F)
write.table(D$Yreg,"~/ycont.txt",row.names=F,col.names=F)
