


#' cx for DC2 regression
someBetaReg = 1:5

#' vars for dc2 regression
dc2Vars = c("X6","X7","X8","X9","X10")

#' continuous dependent var in DC2... so the correlation is 0
dc2Continuous = as.matrix(someD[,dc2Vars]) %*% someBetaReg + rnorm(somenObs)
