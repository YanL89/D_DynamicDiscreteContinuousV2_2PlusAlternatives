library(dcmodels)

# model spec
generic = list(c("X1","X2","X3"))
specific = list(c("X4"), c("X5"), c("X6"))
ASC = FALSE # to keep it fast

# utility coefficients. typically you don't know that 
# but we're generating choices here
b = c(-1,1,1,1)
# covariance of differences, typically you don't know that either
SDiff = matrix(c(1, 0.5, 0.5, 1),2,2)

# if you supply your data you don't need this
nObs = 500 # to keep it fast
nVars = 6
type = "norm"
seed = 1234
D = genData(nObs, nVars, type, seed)
choiceProbit = genChoiceProbit(generic, specific, b, D, NULL, SDiff, ASC)
D$Y = choiceProbit

#' specifications of the probit, same than the logit
specProbit = list(
  generic = generic,
  specific = specific,
  ASC = ASC,
  Y = "Y",
  SD = "hessian")

#' run the probit
modelProbit = model(probit, specProbit, D)
