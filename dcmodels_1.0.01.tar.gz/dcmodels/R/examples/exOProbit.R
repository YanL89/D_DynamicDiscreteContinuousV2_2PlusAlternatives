library(dcmodels)

Z = c("X1","X2","X3","X4","X5")

# if you supply your data you don't need this
a = c(1,1)
b = c(1, -1, 0.5, 0.5, 2)
nObs = 1000
nVars = 5
type = "norm"
seed = 1234
D = genData(nObs, nVars, type, seed)
D$Y = genOprobit(Z, b, a, D)

# there is not much to specify for the ordered probit
specOProbit = list(
  Y = "Y",  
  Z = c("const",Z)
)

modelOProbit = model(oprobit, specOProbit, D)
