library(dcmodels)

n = 1000
p = 8
D = data.frame(matrix(rnorm(n*p),n,p))
D$one = 1
D$zero = 0

common = list(c("one","one","zero","zero"),
		c("zero","zero","one","one"),
		c("X1","X2","zero","zero"),
		c("zero","zero","X3","X4"))
specific = list(c("X5"),c("X6"),c("X7"),c("X8"))

m = list(common = common, specific = specific)
b = c(0.5,1,1,-1,2,-1,1,-2)

# this is a matrix where (U1,U2) are correlated and (U3,U4)
# are correlated
S = matrix(c(1,0.5,0,0,0.5,1,0,0,0,0,1,0.5,0,0,0.5,1),4,4)

# M transforms the error terms into differences against 1st
# error term
M = dcmodels::cov2diff(4,1)

# Variance of differences
SDiff = M %*% S %*% t(M)

# generate choices
D$Y = dcmodels::genChoiceProbit(m,b,D,NULL,SDiff)
D$YSplit = 1 + 1 * (D$Y >= 3)

spec = list(
	split = list(
	  common = list(),
	  specific = list(c(),c())),
	nests = list(
		list(common = list(c("one","one"),c("X1","X2"))
				, specific=list(c("X5"),c("X6"))),
		list(common = list(c("X3","X4"))
				, specific=list(c("X7"),c("X8")))),
	YSplit = "YSplit",
	Y = "Y",
  	SD = "hessian")
	
#args = dcmodels::nlogit$computeArgs(spec, D)
#b = dcmodels::nlogit$computeStart(spec, D)
#sum(log(nlogit$LLVec(b,args)))

M = model(nlogit, spec, D)

specProbit  = list(
  common = common,
  specific = specific,
  method = "pmvnorm",
  Y  = "Y",
  SD = "none"
  )

#MP = model(probit, specProbit, D)
