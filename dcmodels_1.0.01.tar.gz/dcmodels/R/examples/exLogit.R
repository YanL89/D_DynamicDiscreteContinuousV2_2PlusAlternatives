library(dcmodels)

# model spec
generic = list(c("X1","X2","X3"))
specific = list(c("X4"), c("X5"), c("X6"))

# utility coefficients. typically you don't know that but we're generating choices here
b = c(-1, 1, 1, 1)

# if you supply your data you don't need this
nObs = 1000
nVars = 6
type = "norm"
seed = 1234
D = genData(nObs, nVars, type, seed)
choiceLogit = genLogit(generic, specific, D, b)
D$Y = choiceLogit

# specification for the logit example
specLogit = list(
  generic = generic,
  specific = specific,
  Y = "Y",
  ASC = TRUE # they should be 0
)

# run the logit
modelLogit = model(logit, specLogit, D)
#logitElas = modelElasticity(logit, logitSpec, logitData, c("X1","X2"))
#logitApply = modelAndApply(logit, logitSpec, logitData, 0.8)
