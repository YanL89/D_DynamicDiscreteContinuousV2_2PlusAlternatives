#' ordered probit model functions
oprobit = list(
  LLVec = function(b, args){
    npar = ncol(args$X)
    n = nrow(args$X)
    beta = b[1:npar]
    alpha = b[(npar+1):length(b)]
    for(i in 2:length(alpha))
      alpha[i] = alpha[i] + alpha[i-1]
    
    z = args$X %*% beta 
    y = args$Y
    probas = rep(0,n)    
    probas[y==0] = pnorm(-z[y==0])
    probas[y==1] = pnorm(alpha[1] - z[y == 1]) - pnorm( -z[y==1])
    if(args$ncat > 3)
      for(i in 2:(args$ncat-2))
        probas[y==i] = pnorm(alpha[i] - z[y == i]) - pnorm(alpha[i-1] - z[y == i])
    probas[y==(args$ncat-1)] = 1 - pnorm(alpha[args$ncat-2] - z[y == (args$ncat-1)])
    probas
  },
  
  computeArgs = function(spec, D){
    X = as.matrix(D[,spec$Z])
    Y = D[[spec$Y]]
    Y = Y - min(Y)
    ncat = length(unique(Y))
    delta = getElem(spec, name = "delta", default = 0.001) 
    list(X = X, Y = Y, ncat = ncat, delta = delta)
  },
  
  computeStart = function(spec, D){
    numPred = length(spec$Z)
    numCut = length(unique(D[,spec$Y])) - 2
    c(rep(0,numPred), rep(1, numCut))
  },
  
  computeMisc = function(spec, D){
    numCut = length(unique(D[,spec$Y])) - 2
    list(names = c(spec$Z, paste("alpha",1:numCut,sep="")))    
  }
) # ordered probit function list
