#' probit model functions
probit = list(
	LLVec = function(x,args){
		X = args[["X"]]
		Y = args[["Y"]]
		
		beta = x[1:ncol(X)]
		#print(beta)
		#L = vec2mat(c(sqrt(2), x[(ncol(X)+1):length(x)]))
		L = vec2mat(c(1, x[(ncol(X)+1):length(x)]))
		
		S = L %*% t(L)
	
		nalt = nrow(S) + 1
		n = length(Y)
	
		U = matrix(X %*% as.matrix(beta), nrow = n, ncol = nalt, byrow = T)
		
		p = rep(0,length(Y))
		for(i in 1:n){
			args2 = list(U = U[i,], choice = Y[i], S = S
						,mu = rep(0,nalt-1), nalt = nalt, draws=args$Z[[i]])
			p[i] = probitL(args2, genz = (args$method == "genz"))
			}
		p
		},

	computeArgs = function(spec,D){
		X = create_X(spec$generic, spec$specific, D, spec$ASC)
		Y = D[[spec$Y]]
		Y = Y - min(Y) + 1
		
		nAlt = length(spec$specific)
		nObs = length(Y)
		nSim = spec$nSim
		Z = list()
		for(i in 1:nObs)
				Z[[i]] = 1
		if("method" %in% names(spec) && "sim" == spec$method)
			for(i in 1:nObs)
				Z[[i]] = matrix(rnorm(nSim * (nAlt-1)), nrow = nAlt-1, ncol = nSim)
		list(X = X, Y = Y, Z = Z)
		},

	computeStart = function(spec, D){
		# estimate the same specification with logit and use that
		# for starting values. that saves a few iterations
		L = model(logit, spec, D)
		beta = L$results$beta_hat / (pi / sqrt(6))
		
		nalt = length(spec$specific)
		# if errors have covariance identity
		# then the differences have covariance identity + 1
		S = t(chol(diag(nalt-1) + 1))
		# the first element is set, we don't estimate it
		c(beta, mat2vec(S)[-1])
		},

	computeMisc = function(spec, D){
		nalt =  length(spec$specific)
		X = create_X(spec$generic, spec$specific, D, spec$ASC)
		var_names = c(colnames(X))
		for(i in 2:(nalt-1))
			for(j in 1:i)
				var_names = c(var_names, paste("L_",i,j,sep=""))
		list(names = var_names)
		}	
	)

#' generates probit choices
#' 
#' @param generic common parameters
#' @param specific specific parameters
#' @param b cx of utilities
#' @param D the data set
#' @param SDiff covariance of differences against 1st alternative
#' @return probit choices
#' @export
#genProbit = function(generic, specific, b, SDiff, D){
#  genChoiceProbit(m = list(common = common, specific = specific), b = b, D = D
#                  , errsDiff = NULL, SDiff = SDiff )
#}
