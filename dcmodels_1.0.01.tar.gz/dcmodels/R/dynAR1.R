#' dyn model functions with AR(1) simulation
dynAR1 = list(
  LLVec = function(b, args){
    nparH = ncol(args$M[[1]][[1]])
    
    alpha = b[1:nparH]
    beta = b[(nparH+1):length(b)]
    
    LL = 0
    B = 10
    set.seed(1234) #### TO CHECK
    
    H = list()
    U = list()
    V = list()
    PAllObs = rep(1,args$spec$nObs)
    #Pall = matrix(0,16, 3)
    for(t in 1:args$spec$nTime){
    
    Wtally = rep(0,args$spec$nTime)
    Rtally = rep(0,args$spec$nTime)
    U1tally = matrix(0,args$spec$nObs,args$spec$nAlt)
    
    # simulation of dynamic attributes here
		row = seq(from = 1, to = args$spec$nObs, by = args$spec$nAlt)
		
		nSimVar = length(args$colIndexX)
		
    for(bsim in 1:B){
    	#simulated values
			Xsim = list()
			for(v in 1:nSimVar){
				Xv = matrix(0,args$spec$nObs,args$spec$nLook+1)
				# for current time period we read the starting point of 
				# the simulation
				Xv[,1] = args$X[[t]][[1]][row + args$rowIndexX[v]- 1,args$colIndexX[v]]
				# for the other time periods we do the simulation
				
				ARpars = args$spec$dynpars[[v]];
				for(j in 2:(args$spec$nLook+1))
					Xv[,j] = dynSimAR(Xv[,j-1],ARpars[1],ARpars[2],ARpars[3])
				Xsim[[v]] = Xv
			}
			
      for(l in 1:(args$spec$nLook+1)){
      	# we don't simulate M yet
        H[[l]] = as.matrix(args$M[[t]][[l]]) %*% alpha
        if(0 == ncol(H[[l]]))
        	H[[l]] = rep(0, args$spec$nObs)
        
        # fill Xl with the l-th replication of EACH dynamic variable	
        Xl = args$X[[t]][[l]]
        for(v in 1:length(args$colIndexX))
					Xl[args$rowIndexX[v] - 1 + row, args$colIndexX[v]] = Xsim[[v]][,l]
					
        U[[l]] = matrix(Xl %*% beta, args$spec$nObs, args$spec$nAlt, byrow = T)
        V[[l]] = UtoV(U[[l]])
      }
      # tally W, U1 and R
      Wtally = Wtally + getW(H,V)
      Rtally = Rtally + getR(U[[1]])
      U1tally = U1tally + U[[1]]
      
      } # END OF SIMULATION
      
      W = Wtally / B
      R = Rtally / B
      U1 = U1tally / B
    
      P = getDynProbas(W,R,U1,args$C[,t])
      P = maxVec(P,args$stop[,t])
      PAllObs = PAllObs * P
    }
    #LL
    PAllObs
  },
  
  computeArgs = function(spec, D){
    Z = spec$First
    M = list()
    X = list()
    
    Zlist = list()
    Zlist[[1]] = Z
    for(t in 1:spec$nTime){
      M[[t]] = list()
      X[[t]] = list()
      for(l in 1:(spec$nLook+1)){
        M[[t]][[l]] = getM(Z, t+l-1, spec)
        Dt = spec$modifyD(spec$D, spec$Time, spec$Global, Z, t+l-1)
        X[[t]][[l]] = create_X(spec$generic, spec$specific, Dt)
      }
      Z = updateZ(Z,spec$D[[t]],spec$C[,t],spec$varNames)
      Zlist[[t+1]] = Z
    }
        
    oneX = X[[1]][[1]]
    # dyn variable indexes
    colIndexX = c()
    rowIndexX = c()
    for(i in spec$dynvar){
    	colIndexX = c(colIndexX, which(colnames(oneX) == i))
    	#rowIndexX = min(which(0 != X[,i])) %% (spec$nAlt + 1)
    	rowIndexX = c(rowIndexX,1)
    }
    
    # check if we reached stop point already
    stopMat = matrix(0, spec$nObs, spec$nTime)
    for(t in 2:spec$nTime)
    	stopMat[,t] = (spec$C[,t-1] %in% spec$stopAlt)  | (stopMat[,t-1] == 1)

    list(spec = spec, M = M, X = X, C = spec$C, stop = stopMat, Zlist = Zlist, colIndexX = colIndexX, rowIndexX = rowIndexX)
    #c(spec, M = M, X = X, stop = stopMat)
  },
  
  computeStart = function(spec, D){
    npar = length(spec$payoff_alt) + length(spec$payoff_time) + length(spec$payoff_global)
    npar = npar + length(spec$generic)
    for(s in spec$specific)
      npar = npar + length(s)
    rep(0, npar)
  },
  
  computeMisc = function(spec, D){
    n = c(spec$payoff_alt, spec$payoff_time, spec$payoff_global)
    comIndex = 1
    for(com in spec$generic){
      n = c(n,paste("common",comIndex,sep="_"))
      comIndex = comIndex + 1
    }
    for(s in spec$specific)
      n = c(n,s)
    list(names = n)
  }
) # dynAR1 function list
