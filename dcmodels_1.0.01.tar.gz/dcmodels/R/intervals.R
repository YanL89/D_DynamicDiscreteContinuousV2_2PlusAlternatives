#' LL or normal obs grouped in intervals
#' 
#' @param theta (mu,sigma)
#' @param count count for each interval
#' @param threshold threshold for each interval including -Inf and +Inf for first and last
#' @param k number of intervals
#' @return LL value
#' @export
interval2normalLL = function(theta, count, threshold, k){
  m = theta[1]
  s = abs(theta[2])
  ll = 0
  for(i in 1:k)
    ll = ll + count[i] * log(pnorm(threshold[i+1], m, s) - pnorm(threshold[i], m, s))
  ll
}

#' Compute MLE for normal in intervals
#' 
#' @param count count for each interval
#' @param threshold threshold for each interval WITHOUT -Inf and +Inf for first and last
#' @return list of mu and sigma
#' @export
interval2normal = function(count, threshold){
  if(length(threshold) != length(count) - 1)
    stop("don't include lower bound of first interval or upper bound of last interval")
  
  k = length(count)
  intMean = c(threshold[1], threshold)
  startMean = sum(count * intMean) / sum(count)
  startSd = threshold[length(threshold)] - threshold[1]
  threshold = c(-Inf, threshold, Inf)
  o = optim(par = c(startMean, startSd), fn = interval2normalLL, control = list(fnscale = -1)
            , method = "BFGS", count = count, threshold = threshold, k = k)
  list(mu = o$par[1], sd = o$par[2])
}

#' Computes a sample from aggregated normal and MLE parameters, with same interval counts.
#' 
#' @param theta list of MLE parameters returned by interval2normal
#' @param count count for each interval
#' @param threshold threshold for each interval WITHOUT -Inf and +Inf for first and last
#' @return the sample
#' @export
intervalSample = function(theta, count, threshold){
  n = sum(count)
  k = length(count)
  threshold = c(-Inf, threshold, Inf)
  samp = c()
  for(i in 1:k){
    ni = count[i]
    plow = pnorm(threshold[i], theta$mu, theta$sd)
    phigh = pnorm(threshold[i+1], theta$mu, theta$sd)
    l = phigh - plow
    u = seq(from = plow + l/(ni+1), length = ni, by = l / (ni + 1))
    samp = c(samp, qnorm(u, theta$mu, theta$sd))
  }
  samp
}

#' Computes a sample from aggregated normal and MLE parameters, IGNORING interval counts.
#' 
#' @param theta list of MLE parameters returned by interval2normal
#' @param n sample size
#' @return the sample
#' @export
intervalSampleGlobal = function(theta, n){
  qnorm(seq(from = 1/(n+1), to = n/(n+1), length = n), theta$mu, theta$sd)
}

#' example for interval stuff
#' 
#' @export
intervalExample = function(){
  nEx = 100
  muEx = 100
  sEx = 15
  xEx = rnorm(nEx, muEx, sEx)
  tEx = c(60, 80, 100, 120, 140)
  tExAug = c(-Inf, tEx, Inf)
  kEx = length(tEx) + 1
  cEx = c()
  for(i in 1:kEx)
    cEx = c(cEx, sum(tExAug[i] < xEx & xEx < tExAug[i+1]))
  thetaEx = interval2normal(cEx, tEx)
  secondSampEx = intervalSample(thetaEx, cEx, tEx)
  secondSampExGlobal = intervalSampleGlobal(thetaEx, nEx)
  
  xEx = sort(xEx)
  plot(xEx, secondSampEx)
  abline(0,1)
  points(xEx, secondSampExGlobal, col = "red")
  
  plot(secondSampEx, secondSampExGlobal)
  return()
}
