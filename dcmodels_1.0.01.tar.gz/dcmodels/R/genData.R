#' generates a data set to produce examples
#' 
#' @param nObs number of observations
#' @param nVar number of variables
#' @param type "exp" or "norm"
#' @param seed random generator seed
#' @export
genData = function(nObs, nVar, type, seed){
  set.seed(seed)
  x = 0
  if("norm" == type)
    x = rnorm(nObs * nVar)
  else
    x = rnorm(nObs * nVar)
  
  x = matrix(x, nrow = nObs, ncol = nVar)
  x = data.frame(x)
  x$const = 1
  x
}
