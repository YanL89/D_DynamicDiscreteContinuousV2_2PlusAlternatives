#' Dicrete-Continuous model version 4
#' fits a probit and a regression with all error terms
#' correlated
dc4 = list(
  LLVec = function(b, args){
    params = dc4Params(b, nparPr = ncol(args$XPr)
                       , nparReg = ncol(args$XReg))
    L = params$L
    YReg = args$YReg
    YPr = args$YPr
    S = L %*% t(L)
		#print(L)
    
    # LL for the regression
    epsilon = YReg - (args$XReg %*% as.matrix(params$betaReg))
    sigma2 = S[nrow(S), ncol(S)]
    LReg = dnorm(epsilon, 0, sqrt(sigma2))
    
    # utilities
    V = args$XPr %*% params$betaPr
    U = matrix(V, nrow = args$n, ncol = args$nalt, byrow = TRUE)
    
    LPr = rep(0, length(args$YPr))
    for(i in 1:length(args$YPr)){
    	draws = NULL
    	genz = TRUE
    	if(args$method == "sim"){
    		draws = args$draws[[i]]
    		genz = FALSE
    		}
    		
      probitArgs = list(nalt = args$nalt
      		, choice = YPr[i]
      		, mu = condMean(S
      				, mu = rep(0, args$nalt)
              , posObs = args$nalt
              , obs = epsilon[i])
          , S = condCov(S, args$nalt)
          , U = U[i,]
          , draws = draws)
			LPr[i] = probitL(probitArgs, genz = genz)
    }
    LReg * LPr
  },
  
  computeArgs = function(spec, D){
    XReg = as.matrix(D[, spec$reg])
    YReg = D[, spec$Yreg ]
    XPr = create_X(spec$generic, spec$specific, D, spec$ASC)
    YPr = D[, spec$Ypr]
    YPr = YPr - min(YPr) + 1	
    nalt = length(spec$specific)
    n = nrow(D)
    draws = NULL
    if(spec$method == "sim"){
    	#print("sim")
    	draws = list()
    	for(i in 1:n)
    		draws[[i]] = matrix(rnorm(spec$nsim * (nalt-1)),nalt-1,spec$nsim)
    }
    args = list(XReg = XReg, YReg = YReg, XPr = XPr, YPr = YPr
                , nalt = nalt, n = n, method = spec$method, draws = draws)
    args
  },
  
  computeStart = function(spec, D){
  	specL = spec
  	specL$SD = "none"
  	specL$Y = spec$Ypr
  	L = model(logit, specL, D)
    nalt = length(spec$specific)
    #specL = list(Y = spec$Ypr, generic = spec$generic
    #		, specific = spec$specific, SD = "none", ASC = spec$ASC)
    #L = model(logit, specL, D)
    formReg = as.formula(paste(spec$Yreg, paste(spec$reg,collapse="+")
                               , sep = " ~ 0 +"))
    R = lm(formReg, D)
    betaPr = L$results$beta_hat / (pi / sqrt(6))
    betaReg = R$coefficients
    sigma2 = mean(R$residuals ** 2)
    
    # error for probit have var I, reg has sigma^2
    S = diag(nalt)
    S[nalt, nalt] = sigma2
    #S[-nalt, -nalt] = S[-nalt, -nalt] + 1
    L = t(chol(S))
    # we fix the first element of L so we remove it
    c(betaPr, betaReg, mat2vec(L)[-1])
  },
  
  computeMisc = function(spec, D)	{
    nalt = length(spec$specific)
    
    # record the names of coefficients
    namesPr = getNames(spec$generic, spec$specific, D, spec$ASC)
    namesReg = spec$reg
    namesSigma = c()
    for(i in 2:nalt)
      for(j in 1:i)
        namesSigma = c(namesSigma,paste("L_",i,j,sep=""))
    names = c(namesPr, namesReg, namesSigma)
    list(names = names)
  },
  
  findStartL = function(m){
    i = 1
    while(m$results$name[i] != "L_21")
      i = i + 1
    i
  },	
  
  reparam = function(m){
    startL = dc4$findStartL(m)
    endL = length(m$results$beta_hat)
    L = vec2mat(c(sqrt(2), m$results$beta_hat[startL:endL]))
    S = L %*% t(L)
    m2 = m
    m2$results = m2$results[1:(startL -1),]
    m2$SigmaDiffFirst = S
    class(m2) = "dc4"
    m2
  },
  
  comparePmvSim = function(m, spec, D, output){
    # calculate LL for Pmv
    specPmv = spec
    specPmv[["method"]] = "pmvnorm"
    
    specSim = spec
    specSim[["method"]] = "simulation"
    if(! "nsim" %in% names(specSim))
      specSim[["nsim"]] = 500
    
    argsPmv = dc4$computeArgs(specPmv, D)
    argsSim = dc4$computeArgs(specSim, D)
    
    pSim = dc4$LLVec(m$results$beta_hat, argsSim)
    pPmv = dc4$LLVec(m$results$beta_hat, argsPmv)
    
    pdf(output)
    plot(pSim, pPmv, xlab = "probas computed with simulation"
         , ylab = "probas computed with pmv"
         , main = "comparision of invididual probabilities"
    )
    abline(lm(pPmv ~ 0 + pSim))
    dev.off()
  },
  
  outputUtilities = function(m, spec, D, output){
    #b = as.vector(m$results$beta_hat)
    args = dc4$computeArgs(spec,D)
    #print(args$X)
    nparPr = length(spec$probit$common)
    for(i in spec$probit$specific)
      nparPr = nparPr + length(i)
    
    betaPr = m$results$beta_hat[1:nparPr]
    U = getUtilities(args$XPr, betaPr, nrow(D))
    U = round(1000*U) / 1000
    p = dc4$LLVec(m$results$beta_hat, args)
    p = round(1000*p) / 1000
    choice = D[,spec[["YPr"]]]
    
    out = data.frame(U = U, choice = choice, p = p)
    write.csv(out, output, quote = FALSE, row.names = FALSE)
  },
  
  comparePis = function(b1, b2, spec, D, output){
    args = dc4$computeArgs(spec, D)
    p1 = dc4$LLVec(b1, args)
    p2 = dc4$LLVec(b2, args)
    pdf(output)
    plot(p1,p2,xlab="p_i with first set of coefficients",
         ylab="p_i with second set", main="comparision of 2 cx sets")
    abline(lm(p2 ~ p1))
    dev.off()
  },
  
  apply = function(b, spec, D){
    XPr = create_X(spec$probit$common, spec$probit$specific, D)	
    XReg = as.matrix(D[,spec$reg])
    params = dc4Params(b,ncol(XPr),ncol(XReg))	
    nalt = length(spec$probit$specific)
    nerr = nalt -1 +1
    n = nrow(D)
    
    # error terms
    err = params$L %*% matrix(rnorm(n*nerr),nrow = nerr, ncol = n)
    errsDiff = t(err[1:(nalt-1),])
    errsReg = err[nalt,]
    
    # calculate dependant varialbe
    # b = params$betaPr
    YPr = genChoiceProbit(spec$probit, params$betaPr, D, errsDiff)
    YReg = XReg %*% params$betaReg + errsReg
    list(Ydisc = YPr, Yreg = YReg)
  }
)
