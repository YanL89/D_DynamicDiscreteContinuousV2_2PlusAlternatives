library("evd")

V = list(
	c(2.5,2.5,2.5,3,3,3)
	, rep(2,3)
	, rep(2,5)
	, rep(2,10)
	, rep(2,100)
	, rep(2,2000)
	, seq(from = 1, to = 5, length = 5)
	, seq(from = 1, to = 10, length = 100)
	, seq(from = 1, to = 15, length = 100)
	, seq(from = 1, to = 20, length = 100)
	)

pdf("mode_logsum.pdf")
for(v in V){
	nvar = length(v)
	modeNoSim = log(sum(exp(v)))
	m = c()
	for(i in 1:100000)
		m = c(m,max(v + rgumbel(nvar)))
	plot(density(m))
	abline(v = modeNoSim)
	}
dev.off()

