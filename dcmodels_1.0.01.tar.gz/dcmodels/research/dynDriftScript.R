library(dcmodels)

# 3 variables, 50 observations.
# this is not what we typically expect
nVar = 3
nObs = 4
X = matrix(rnorm(nVar * nObs), nObs, nVar)

for(t in 2:nObs)
	X[t,] = X[t-1,] + rep(0.05, nVar) + rnorm(nVar)

drift1SS = function(X){
	T = nrow(X)
	nu = (X[T,] - X[1,]) / (T - 1)
	res = X[-1,] - X[-T,] - nu
	S = var(res)
	list(nu = nu, S = S)
}

nu = rep(0,nVar)
S = matrix(0, nVar, nVar)
for(i in 1:1000){
	X = matrix(rnorm(nVar * nObs), nObs, nVar)
	M = drift1SS(X)
	nu = nu + M$nu
	S = S + M$S
	}

optim(
#theta = c(rep(0,nVar), mat2vec(diag(nVar)))


