common = list(c("cost_car","cost_transit","cost_bike"))
specific = list(c("time_car","tolls"), c("time_transit"), c())
