modifyD = function(D,Tau,G,Z,t){
	Dticket = D[[t]]
	
	# add diff1 to diff15
	for(i in 1:15){
		Dticket[,paste("diff",i,sep="")] = Dticket[,paste("cost",i,sep=".")] -
			Z$cost
	}

	# add t1 and t16
	Dticket$t1 = 1* (1 == t)
	Dticket$t16 = 1* (16 == t)

	# append G 
	Dticket = cbind(Dpratt, G)

	Dticket$farepaid = Z$cost
	Dticket
}

