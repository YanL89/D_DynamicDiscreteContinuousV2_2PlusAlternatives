common = list()
specific = list(c("time_car"), c("time_transit"), c("time_bike"))
