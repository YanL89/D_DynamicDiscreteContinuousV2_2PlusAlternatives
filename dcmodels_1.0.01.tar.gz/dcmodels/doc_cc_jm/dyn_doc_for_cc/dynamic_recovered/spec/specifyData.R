# data files are in the vars/ repertory

# cerresponds to file names alternatives1.txt to
# alternatives18.txt for T = 16 and L = 2
D = "vars/alternatives",
Time = "vars/time.txt",
Global = "vars/global.txt",
First = "vars/first.txt",
choices = "vars/choices.txt",
