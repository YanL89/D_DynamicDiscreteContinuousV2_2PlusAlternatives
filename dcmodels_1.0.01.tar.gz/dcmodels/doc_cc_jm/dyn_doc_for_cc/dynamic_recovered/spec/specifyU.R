# diffi and B_ex and B_16 are the same so we put them in common
# (for common parameter). The trailing "zero" is because it does 
# not affect the last alternative
	common = list(
		c("diff1","diff2","diff3","diff4","diff5","diff6","diff7","diff8"
			,"diff9","diff10","diff11","diff12","diff13","diff14"
			,"diff15","zero"),
		c("one","one","one","one","one","one","one","one","one","one","one"
			,"one","one","one","one","zero"),
		c("t16","t16","t16","t16","t16","t16","t16","t16","t16","t16","t16"
			,"t16","t16","t16","t16","zero")),
	specific = list(
		c(), # 1
		c(), # 2
		c(), # 3
		c(), # 4
		c(), # 5
		c(), # 6
		c(), # 7
		c(), # 8
		c(), # 9
		c(), # 10
		c(), # 11
		c(), # 12
		c(), # 13
		c(), # 14
		c(), # 15
		c("one","t1","evening","friday","philly","farepaid")), # 16
