payoff_alt = c() # no variable from Z
payoff_time = c("t16") # t16 from T
payoff_global = c() # no variable from G
