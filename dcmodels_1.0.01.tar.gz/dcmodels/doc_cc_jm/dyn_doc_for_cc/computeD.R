modifyD = function(D,Tau,G,Z,t){
	Dticket = D[[t]]
		for(i in 1:15){
			Dticket[,paste("diff",i,sep="")] = Dticket[,paste("cost",i,sep=".")] -
				Z$cost
		}

	#supplied function, extracts variables for time t
	Timet = Time_select_vars(Tau,"t1",t)

	Dticket$time1 = Timet$t1
	Dticket$timeothers = 1 - Dpratt$time1

	# append G 
	Dticket = cbind(Dpratt, G)

	Dticket$farepaid = Z$cost
	Dticket
}

