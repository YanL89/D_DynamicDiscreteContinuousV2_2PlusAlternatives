#' some common coefficients
genericLogit = list(c("X1","X2","X3"))

#' some specific parameters
specificLogit = list(c("X4"), c("X5"), c("X6"))

# assume you have read your data somehow
# DLogit = read.table("somefile.txt",header=TRUE)

specLogit = list(
  generic = genericLogit,
  specific = specificLogit,
  Y = "Y"
)

modelLogit = model(logit, specLogit, DLogit)
