double Probit::probaSim(const arma::rowvec& d, const arma::mat& L
		, int choice, int obs){
	arma::mat err = L * z.at(obs);
	int nsucc = 0;
	for(int i = 0; i < nsim; ++i){
		bool is_suc = true;
		for(int diff = 0; diff < nalt - 1; ++diff)
			if(err(diff,i) > d(diff)){
				is_suc = false;
				break;
			}
		if(is_suc)
			nsucc++;
	}
	
	if(nsucc)
		return ((double) nsucc) / ((double) nsim);
	else
		// cannot return a 0 probability, so we return 0.1 succes / nsim
		return 0.1/ ((double) nsim);
}

