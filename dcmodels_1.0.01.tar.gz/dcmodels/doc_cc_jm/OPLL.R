OPLL = function(b, X, Y){
	# your code here
}
