getPAlts = function(U){
	U = exp(U)
	U / rowSums(U)
}
