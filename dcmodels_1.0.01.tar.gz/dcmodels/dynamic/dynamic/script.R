source("sim.R")
source("spec.R")
source("test.R")
source("check.R")

pratt = checkFillDynSpec(pratt)

B = 1000
	npar = length(pratt$b)
	betaHatMat = matrix(0, npar,B)
sdMat = matrix(0, npar, B)

	for(b in 1:B){	
		print(b)
			C = simDynamic(pratt)
			C = C$Ch
			results = dyn(pratt, C, pratt$b)
			betaHatMat[,b] = results$beta_hat
			sdMat[,b] = results$sd
	}

covers = rep(0,10)

for(i in 1:B){
	covers = covers + 1*((betaHatMat[,i] - 1.96 * sdMat[,i]) < realpar &
	(betaHatMat[,i] + 1.96 * sdMat[,i]) > realpar)
}
