nObs = 696
nTime = 16
nLook = 2

t1 = matrix(0,nObs,nTime+nLook)
t1[,1] = 1

t215 = matrix(1,nObs,nTime+nLook)
t215[,c(1,16,17,18)] = 0

t16 = matrix(0,nObs,nTime+nLook)
t16[,16] = 1

D = cbind(t1,t215,t16)

colnames(D) = c(paste("t1",1:18,sep="."),paste("t215",1:18,sep="."),
		paste("t16",1:18,sep="."))
write.table(D,"time.txt",quote=F, row.names=F)
