source("dyn.R")

testDyn = function(spec, B){
	npar = length(spec$b)
	list(betaHatMat = betaHatMat, sdMat = sdMat)
}
