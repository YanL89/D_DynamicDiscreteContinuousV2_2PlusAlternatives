jm = list(
	# data sets
	D = "vars/alternatives",
	Time = "vars/time.txt",
	Global = "vars/global.txt",
	First = "vars/first.txt",
	choices = "vars/choices_real.data",
	
	# speficy one period payoffs
	payoff_alt = c(),
	payoff_time = c("t16"),
	payoff_global = c(),
	
	# specify utilities. variables here must be created
	# in the modifyD function
	common = list(
		c("diff1","diff2","diff3","diff4","diff5","diff6","diff7","diff8"
			,"diff9","diff10","diff11","diff12","diff13","diff14"
			,"diff15","zero"),
		c("t","t","t","t","t","t","t","t","t","t","t","t","t","t","t","zero")),
	specific = list(
		c(), # 1
		c(), # 2
		c(), # 3
		c(), # 4
		c(), # 5
		c(), # 6
		c(), # 7
		c(), # 8
		c(), # 9
		c(), # 10
		c(), # 11
		c(), # 12
		c(), # 13
		c(), # 14
		c(), # 15
		c("one","group","morning","monday","friday","philly","nyc","farepaid","t")), # 16

	# function to create data set at time t
	modifyD = function(D,Time,Global,Z,t){
		Djm = D[[t]]
		for(i in 1:15){
			Djm[,paste("diff",i,sep="")] = Djm[,paste("cost",i,sep=".")] - Z$cost
		}
		
		#Timet = Time_select_vars(Time,"t1",t)

		#Dpratt$t1 = 1*(t==1)
		#Dpratt$t16 = 1*(t==16)
		#Dpratt$t215 = 1*(t > 1 && t < 16)
		#Dpratt$t216 = 1*(t > 1 && t <= 16)
		Djm = cbind(Djm, Global)
		Djm$one = 1
		Djm$zero = 0
		Djm$farepaid = Z$cost
		Djm$t = t
		Djm
	},

	# starting parameter, if unspecified will be set to 0
	#b = c(c(2), c(-0.01, -7, 7, -5, 3, 1, -1, 1, 0.01))
	b = rep(0, 12)
)
