nTime = 16
nObs = 696

source("~/Documents/library_dcm/utils/create_X.R")

Cpratt = read.table("/home/jm/Documents/Pratt_Thesis_Dynamic_Model/sim_model/gen/choice.txt", header = FALSE)

formatChoice = function(i){
	if(17 == i)
		return(-1)
	if(16 == i)
		return(0)
	i
}

C = matrix(0, nObs, nTime)
for(obs in 1:nObs)
	for(t in 1:nTime){
		index = 2 + 17*(t-1)
		choices = Cpratt[obs, index:(index+17-1)]
		choiceInt = which(choices == 1)
		
		C[obs,t] = formatChoice(choiceInt)
		}

FPratt = read.table("/home/jm/Documents/Pratt_Thesis_Dynamic_Model/sim_model/gen/poten.txt", header = FALSE)

Dindiv = read.table("~/Documents/dynamic/evening_friday_philly.txt", header = TRUE)

Current = read.table("/home/jm/Documents/Pratt_Thesis_Dynamic_Model/sim_model/gen/current.txt", header = FALSE)
FirstTicket = rowMeans(Current[,-1])
FT = data.frame(cost = FirstTicket)

write.table(FT, "first.txt", row.names = FALSE, quote = FALSE)
D = list()
index = 2
fareNames = paste("cost",1:15,sep=".")
for(day in 1:16){
	D[[day]] = FPratt[,index:(index + 15-1)]
	index = index + 15
	colnames(D[[day]]) = fareNames
	D[[day]]$fare.16 = rep(0,nObs)
	#D[[day]]$one = rep(1,nObs)
	#D[[day]]$zero = rep(0, nrow(D[[day]]))
	#D[[day]]$friday = Dindiv$friday
	#D[[day]]$evening = Dindiv$evening
	#D[[day]]$philly = Dindiv$philly
	#D[[day]]$farepaid = FT[,1]
	#D[[day]]$constday1 = rep(0, nrow(D[[day]]))
	#if(1 == day)
	#	D[[day]]$constday1 = rep(1, nrow(D[[day]]))
	
	#D[[day]]$constotherdays = rep(0, nrow(D[[day]]))
	#if(1 != day)
	#	D[[day]]$constotherdays = rep(1, nrow(D[[day]]))
	#D[[day]]$isdepday = rep(1*(day == 16), nObs)
	}
for(day in 17:18){
	D[[day]] = D[[1]]
	for(i in 1:ncol(D[[day]]))
		D[[day]][,i] = rep(0, nObs)
	}
for(day in 1:18)
	write.table(D[[day]], paste("alternatives",day,".txt",sep=""),
			quote = FALSE,	row.names = FALSE)

X = list()
for(day in 1:nTime)
	X[[day]] = create_X(common, specific, D[[day]])
for(day in (nTime+1):(nTime+2))
	X[[day]] = matrix(0, nrow(X[[1]]), ncol(X[[1]]))
CurrPratt = read.table("/home/jm/Documents/Pratt_Thesis_Dynamic_Model/sim_model/gen/poten.txt", header = FALSE)

common = list(c("diff_5","diff_6","diff_7","diff_8","diff_9",
		"diff_10","diff_11","diff_12","diff_13","diff_14","diff_15",
		"diff_16","diff_17","diff_18","diff_19","zero"))

specific = list(c(),c(),c(),c(),c(),c(),c(),c(),c(),c(),
		c(),c(),c(),c(),c(), 
		c("constday1","constotherdays","friday","philly","farepaid"))

hold = c("isdepday")


Hlist = list()
for(day in 1:(nTime+1))
	Hlist[[day]] = matrix(1 * (day == 16), 696, 1)
	

getV = function(beta, args){
	
	for(i in 1:nTime)
}

