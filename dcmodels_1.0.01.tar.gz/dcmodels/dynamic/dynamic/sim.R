source("~/Documents/library_dcm/utils/create_X.R")
source("functions.R")

#sim = function(b, D, Time, Global, First, modifyD,
#		payoff_alt, payoff_time, payoff_global, nObs, nTime, nLook, nAlt,
#		altVarNames, common, specific){
simDynamic = function(spec){
	nparH = length(spec$payoff_alt) + length(spec$payoff_time) 
			+ length(spec$payoff_global)
	# parameter of payoff utilities
	alpha = spec$b[1:nparH]
	# parameter of (normal) utilities
	beta = spec$b[(nparH+1):length(spec$b)]
	
	Ch = matrix(0, spec$nObs, spec$nTime)

	Wlist = list()
	Rlist = list()
	Ulist = list()
	Z = spec$First
	for(t in 1:spec$nTime){
		M = list()
		H = list()
		X = list()
		U = list()
		V = list()
		for(l in 1:(spec$nLook+1)){
			M[[l]] = getM(Z, spec$Time, spec$Global, t + l - 1, spec$payoff_alt
					, spec$payoff_time, spec$payoff_global)
			H[[l]] = as.matrix(M[[l]]) %*% as.vector(alpha)
			Dt = spec$modifyD(spec$D, spec$Time, spec$Global, Z, t + l - 1)
			X[[l]] = create_X(spec$common, spec$specific, Dt)
			U[[l]] = matrix(X[[l]] %*% beta, nrow = spec$nObs, ncol = spec$nAlt
					, byrow = TRUE)
			V[[l]] = UtoV(U[[l]])
		}

		W = getW(H, V)
		R = getR(U[[1]])
		Wlist[[t]] = W
		Rlist[[t]] = R
		Ulist[[t]] = U[[1]]

		choices = getDynChoice(W,R,U[[1]])
		Ch[,t] = choices
		# now we also need to update Z for those that changed their alternative
		Z = updateZ(Z,spec$D[[t]],choices,spec$varNames)
	}
	list(Ch = Ch, W = Wlist, R = Rlist,U = Ulist)
}
