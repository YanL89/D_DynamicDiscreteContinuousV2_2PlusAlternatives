source("~/Documents/library_dcm/utils/create_X.R")


dynamic_gen = function(D, Time, Global, First, b){
	

}
