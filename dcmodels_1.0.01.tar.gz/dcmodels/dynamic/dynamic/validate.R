source("sim.R")
source("spec.R")
source("test.R")
source("check.R")

spec = pratt
frackeep = 0.8
validateDyn = function(spec, frackeep){
	system("mkdir -p validate")
	spec2 = checkFillDynSpec(spec)
	specVal = spec
	nObs = spec2$nObs
	maxIndex = round(nObs * frackeep)

	# data of utilities
	nd = spec2$nTime + spec2$nLook
	for(t in 1:nd){
		n = paste(spec$D,t,sep="")
		n = paste(n,"txt",sep=".")
		D = read.table(n,header=T)
		nout = paste("validate","alternatives",sep="/")
		nout = paste(nout,t,sep="")
		nout = paste(nout,"txt",sep=".")
		write.table(D[1:maxIndex,],nout,quote=F,row.names=F)
	}
	specVal$D = "validate/alternatives"

	# global
	G = read.table(spec$Global,header=T)
	write.table(G[1:maxIndex,],"validate/global.txt",quote=F,row.names=F)
	specVal$Global = "validate/global.txt"

	# time
	Ti = read.table(spec$Time,header=T)
	write.table(Ti[1:maxIndex,],"validate/time.txt",quote=F,row.names=F)
	specVal$Time = "validate/time.txt"

	# first
	Fi = read.table(spec$First,header=T)
	write.table(Fi[1:maxIndex,],"validate/first.txt",quote=F,row.names=F)
	specVal$First = "validate/first.txt"

	# choices
	C = read.table(spec$choices,header=F)
	write.table(C[1:maxIndex,],"validate/choices.txt"
			,row.names=F,col.names=F)
	Ckeep = C[1:maxIndex,]
	Cval = C[(maxIndex+1):nrow(C),]
	specVal$choices = "validate/choices.txt"

	specVal = checkFillDynSpec(specVal)
	dynres = dyn(specVal, Ckeep, specVal$b)
	spec$b = dynres$beta_hat
	specSim = checkFillDynSpec(spec)
	Watmax = simDynamic(specSim)

	Pred = matrix(nrow = specSim$nTime, ncol=specSim$nAlt+1,0)
	Val = Pred
	for(t in 1:specSim$nTime){
		PK = exp(-exp(-(Watmax$W[[t]] - Watmax$R[[t]])))
		
		Pred[t,1] = sum(PK[-(1:maxIndex)])
		PL =  exp(Watmax$U[[t]]) / rowSums(exp(Watmax$U[[t]]))
		for(col in 1:ncol(PL))
			PL[,col] = PL[,col] * (1 - PK)

		PL = PL[-(1:maxIndex),]
		Pred[t,-1] = colSums(PL)

		for(a in 0:specSim$nAlt)
			Val[t,a+1] = sum(Cval[,t] == a)
	}		
	list(Pred = Pred, Val = Val)
}
