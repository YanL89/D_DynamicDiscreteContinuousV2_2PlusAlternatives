source("logitUtils.R")

library(evd)

Time_select_vars = function (Time, vars, t){
	TimeSelect = data.frame(Time[,paste(vars,t,sep=".")])
	names(TimeSelect) = vars
	TimeSelect
}

getM = function(Z,Time,Global, t, payoff_alt, payoff_time, payoff_global){
	Timet = Time_select_vars(Time, payoff_time, t)
	cbind(Z[,payoff_alt], Timet, Global[, payoff_global])
}

getW = function(H, V){
	l = length(H)
	W = maxVec(V[[l]], H[[l]])

	l = l - 1
	while(l > 1){
		W = maxVec(V[[l]], H[[l]] + W) 
		l = l - 1
	}
	H[[1]] + W
}

getR = function(V){
	log(rowSums(exp(V)))
}

UtoV = function(U){
	apply(U,1,max)
}

maxVec = function(v1,v2){
	apply(cbind(v1,v2),1,max)
}

getPKeep = function(W,R){
	exp(-exp(-(W-R)))
}

getChoiceLogit = function(U){
	U = U + matrix(rgumbel(nrow(U) * ncol(U)), nrow(U), ncol(U))
	apply(U,1,which.max)
}

getDynChoice = function(W, R, U){
	PK = getPKeep(W,R)
	C = rep(-1,length(W))

	CLogit = getChoiceLogit(U)
	for(i in 1:length(W)){
		draw = runif(1)
		if(draw <= PK[i])
			C[i] = 0
		if(draw > PK[i])
			C[i] = CLogit[i] 
	}
	C
}

updateZ = function(Z,D,choices, altVarNames){
	for(i in 1:nrow(Z))
		# if choice == 0 the person has not changed his item so his Z
		# does not need to be updated
		if(choices[i] != 0)
			Z[i,altVarNames] = D[i,paste(altVarNames,choices[i],sep=".")]
	Z
}

getDynProbas = function(W,R,U,Choices){
	P = rep(0, length(W))

	PK = getPKeep(W,R)
	PA = getPAlts(U)
	P[Choices == 0] = PK[Choices == 0]
	for(a in 1:ncol(U))
		P[Choices == a] = (1 - PK[Choices == a]) * PA[Choices == a, a]
	P
}
