library(dcmodels)
source("spec.R")
source("check.R")
spec = checkFillDynSpec(pratt)

Call = read.table("vars/choices.txt",header = FALSE)
Y = Call[,1]
G = read.table("vars/global.txt",header = TRUE)
Fi = read.table("vars/first.txt",header = TRUE)
Djustone = read.table("vars/alternatives1.txt",header=TRUE)

newD = data.frame(G,Y)
for(i in 1:15)
	newD[,paste("diff",i,sep="")] = Djustone[,paste("cost",i,sep=".")] -
			Fi[,"cost"]
newD[,"timeothers"] = 0
newD[,"farepaid"] = Fi$cost
common = list(
		c("zero", "diff1","diff2","diff3","diff4","diff5","diff6","diff7"
			,"diff8"
			,"diff9","diff10","diff11","diff12","diff13","diff14"
			,"diff15","zero"),
		c("zero"
			, "one","one","one","one","one","one","one","one","one","one","one"
			,"one","one","one","one","zero"))
specific = list(
		c(), # keep
		c(), # 1
		c(), # 2
		c(), # 3
		c(), # 4
		c(), # 5
		c(), # 6
		c(), # 7
		c(), # 8
		c(), # 9
		c(), # 10
		c(), # 11
		c(), # 12
		c(), # 13
		c(), # 14
		c(), # 15
		# we cannot add time indication variables here since they
		# are degenerate and pooled with the constant, however
		# there was no constant in the dynamic model since we add
		# constant that depended on the time.
		c("one","evening","friday","philly","farepaid")) # 16

logitspec = list(
	common = common,
	specific = specific,
	Y = "Y",
	SD = "hessian")

# first attemp : only the first choices for t=1
M1 = model(logit, logitspec, newD)


# with all data
getDAll = function(D,C){
	varsInDt = c(paste("diff",1:15,sep=""),
			"evening","group", "morning", "monday", "friday", "philly", "nyc"
			,"farepaid")

	Z = spec$First

	nall = 696 * 16
	Dall = data.frame(
		diff1 = rep(0,nall),
		diff2 = rep(0,nall),
		diff3 = rep(0,nall),
		diff4 = rep(0,nall),
		diff5 = rep(0,nall),
		diff6 = rep(0,nall),
		diff7 = rep(0,nall),
		diff8 = rep(0,nall),
		diff9 = rep(0,nall),
		diff10 = rep(0,nall),
		diff11 = rep(0,nall),
		diff12 = rep(0,nall),
		diff13 = rep(0,nall),
		diff14 = rep(0,nall),
		diff15 = rep(0,nall),
		t16 = rep(0, nall),
		t1 = rep(0, nall),
		evening = rep(0,nall),
		group = rep(0,nall),
		morning = rep(0,nall),
		evening =  rep(0,nall),
		monday = rep(0, nall),
		friday =  rep(0,nall),
		philly =  rep(0,nall),
		nyc = rep(0, nall),
		farepaid = rep(0,nall))
	for(t in 1:spec$nTime){
		indexes = seq(from = 696*(t-1)+1,length = 696)
		Dt = spec$modifyD(spec$D, spec$Time, spec$Global, Z, t)
		Dall[indexes, "farepaid"] = Z$cost
		Z = updateZ(Z,spec$D[[t]],C[,t],spec$varNames)
		Dall[indexes,varsInDt] = Dt[,varsInDt]
		Dall[indexes,"t16"] = 1 * (t == 16)
		Dall[indexes,"t1"] = 1 * (t == 1)
		Dall[indexes,"t"] = t
		}
	Dall$zero = 0
	Dall$one = 1
	Dall
	}

Dall = getDAll(spec$D,Call)
indexesK = c()
indexesV = c()
lK = 557
lV = 696 - 557
st = 1
for(i in 1:16){
	indexesK = c(indexesK, seq(from = st, length = lK))
	indexesV = c(indexesV, seq(from = st + lK, length = lV))
	st = st+696
}

commonall = list(
		c("zero", "diff1","diff2","diff3","diff4","diff5","diff6","diff7","diff8"
			,"diff9","diff10","diff11","diff12","diff13","diff14"
			,"diff15","zero"),
		c("zero", "t","t","t","t","t","t","t","t","t","t","t","t","t","t","t"
			,"zero"))
specificall = list(
					c("t16"),
					 c(), # 1
					 c(), # 2
				 c(), # 3
				 c(), # 4
				 c(), # 5
				 c(), # 6
				 c(), # 7
				 c(), # 8
				 c(), # 9
				 c(), # 10
				 c(), # 11
				 c(), # 12
				 c(), # 13
				 c(), # 14
				 c(), # 15
				 c("one","group","morning","monday","friday","philly","nyc","farepaid","t"))

commonall = list(
	c("zero","diff1","diff2","diff3","diff4","diff5","diff6","diff7","diff8"
		,"diff9","diff10","diff11","diff12","diff13","diff14"
		,"diff15","zero"),
	c("zero","one","one","one","one","one","one","one","one","one","one","one"
		,"one","one","one","one","zero"),
	c("zero", "t16", "t16", "t16", "t16", "t16", "t16", "t16", "t16", "t16"
		, "t16", "t16", "t16", "t16", "t16", "t16", "zero"))
specificall = list(
	c("t16"),
	c(), # 1
	c(), # 2
	c(), # 3
	c(), # 4
	c(), # 5
	c(), # 6
	c(), # 7
	c(), # 8
	c(), # 9
	c(), # 10
	c(), # 11
	c(), # 12
	c(), # 13
	c(), # 14
	c(), # 15
	c("one","t1","evening","friday","philly","farepaid")) # 16

Yall = c()
for(i in 1:16)
	Yall = c(Yall, Call[,i])

Dall$Yall = Yall

specAll = list(
	common = commonall,
	specific = specificall,
	Y = "Yall",
	SD = "hessian")

M2 = model(logit, specAll, Dall[indexesK,])
DV = Dall[indexesV,]
XV = create_X(commonall, specificall, DV)
U = matrix(XV %*% M2$results$beta_hat, ncol = 17, byrow = T)
U = exp(U)
denom = rowSums(U)
for(i in 1:17)
	U[,i] = U[,i] / denom

Pred = matrix(0, 16, 3)

for(i in 1:16){
	Ui = U[seq(from = lV*(i-1) + 1, length = lV),]
	Pred[i,1] = sum(Ui[,1])
	Pred[i,2] = sum(Ui[,2:16])
	Pred[i,3] = sum(Ui[,17])
	#print(seq(from = lV*(i-1) + 1, length = lV))
}


