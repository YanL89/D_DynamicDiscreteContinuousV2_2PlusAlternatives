source("sim.R")
source("spec.R")
source("test.R")
source("check.R")

tableChoices = function(C){
	D = data.frame(keep = rep(0,16), exchange = rep(0,16), cancel = rep(0,16))
	for(t in 1:16){
		D[t,c("keep","exchange","cancel")] = c(sum(C[,t] == 0), 
				sum(C[,t] %in% 1:15), sum(C[,t] == 16))
	}
	D
}

pratt = checkFillDynSpec(pratt)

# @Cinzia c'est ici qu'on rentre les parametres
# j'ai change time1 et timeothers pour t1 et t16 pour qu'on puisse
# avoir beaucoup de cancellation aux jours 1 et 16
pratt$b =c(
	2,     # alpha_1 le coefficient de t16 dans les one-period
	-0.01, # beta_cost (exchange)
	-7,    # beta_c (exchange)
	7,     # t16 (exchange)
	-5,    #  const (cancel)
	3,    # t1 (cancel) j'ai change timeothers pour t16
	1,     # evening (cancel)
	-1,    # friday (cancel)
	1,     # philly (cancel)
	0.01)  # farepaid (cancel)

set.seed(4321)
C = simDynamic(pratt)
C = C$Ch
#write.table(C, "vars/choices.txt", quote = F, row.names = F, col.names=F)
tableChoices(C)
