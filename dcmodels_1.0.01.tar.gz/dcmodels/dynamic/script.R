source("~/Documents/library_dcm/utils/create_X.R")
source("functions.R")
source("dynamic.gen.R")




# we cannot specify the variables that are used to compute the utilities
# at each time period because they depend on variables that
# not availalbe right now
calculate_X = function(D,Time,Global,First,Choices){
	
}

# specification of utilities
# common = list(c("diff_5","diff_6","diff_7","diff_8","diff_9",
#		"diff_10","diff_11","diff_12","diff_13","diff_14","diff_15",
#		"diff_16","diff_17","diff_18","diff_19","zero"),
#		c("one","one","one","one","one","one","one","one","one",
#		"one","one","one","one","one","one","zero"))
# specific = list(c(),c(),c(),c(),c(),c(),c(),c(),c(),c(),
#		c(),c(),c(),c(),c(), 
#		c("constday1","constotherdays","friday","philly", "evening"
#				,"farepaid"))
# hold = c("isdepday")

# design matrix for pay off utilities
Hlist = list()
for(day in 1:(nTime + 1))
	Hlist[[day]] = as.matrix(D[[day]][,hold])

# beta of alternatives and payoff
#betaAlts = c(-0.02, 3, -5, -2, 4, 2.5,  0.03)
betaAlts = c(-0.02, -6, -5, -4, 1, -1, 1, 0.02)
betaPay = as.vector(c(2))

#construct fare differences
X = list()
for(day in 1:(nTime + 2)){

	for(t in 5:19){
		nameFare = paste("fare",t,sep="_")
		nameDiff = paste("diff",t,sep="_")
		if(day <= nTime){
			D[[day]][,nameDiff] = D[[day]][,nameFare] - first
			} else{
			D[[day]][,nameDiff] = 0
			}
		}
	X[[day]] = create_X(common, specific, D[[day]])
}

#probability of alternatives
PALTS = list()
UALTS = list()
for(day in 1:nTime){
	U = matrix(X[[day]] %*% betaAlts, nObs, nAlt, byrow = TRUE)
	UALTS[[day]] = U
	U = exp(U)
	denom = rowSums(U)
	for(t in 1:ncol(U))
		U[,t] = U[,t] / denom
	PALTS[[day]] = U
}

args = list(X = X, H = Hlist, nObs = nObs, nAlt = nAlt, nTime = nTime,
		nLook = 2)
V = getV(betaAlts, args)
H = getH(betaPay, args)
W = getW(args, V, H)
R = getR(betaAlts, args)

PKeep = exp(-exp(-(W-R)))

choices = matrix(0, nObs, nTime)
for(obs in 1:nObs)
	for(t in 1:nTime)
		if(runif(1) < PKeep[obs,t]){
			choices[obs, t] = -1
		} else {
			choices[obs, t] = which.max(UALTS[[t]][obs,] + rgumbel(16))
		}

LL = function(beta, X, choices, args){
	betaA = beta[1:8]
	betaP = as.vector(beta[9])
	
	V = getV(betaA, args)
	H = getH(betaP, args)
	W = getW(args, V, H)
	R = getR(betaA, args)
	
	PKeep = exp(-exp(-(W-R)))
	
	P = list()
	for(day in 1:nTime){
		U = matrix(X[[day]] %*% betaA, nObs, nAlt, byrow = TRUE)
		U = exp(U)
		denom = rowSums(U)
		for(t in 1:ncol(U))
			U[,t] = U[,t] / denom
		P[[day]] = U
		}
	ll = 0

	for(t in 1:nTime)
		for(obs in 1:nObs)
			if(-1 == choices[obs,t]){
				ll = ll + log(PKeep[obs,t])
			} else{
				ll = ll + log((1-PKeep[obs,t]) * P[[t]][obs,choices[obs,t]])
			}
	ll	
}

O = optim(par = rep(0,9), fn = LL, method = "BFGS", 
		control = list(fnscale = -1), X = X, choices = choices, args = args)
